using System.Collections;
using System.Collections.Generic;
using UnityEngine.Networking;
using UnityEngine;

public class GameService
{

    public static IEnumerator Example()
    {
        // Create a UnityWebRequest object
        UnityWebRequest request = UnityWebRequest.Get("https://jsonplaceholder.typicode.com/todos/1");

        // Send the request and wait for a response
        yield return request.SendWebRequest();

        // Check for errors
        if (request.result != UnityWebRequest.Result.Success)
        {
            Debug.Log(request.error);
        }
        else
        {
            // Print the response body
            Debug.Log(request.downloadHandler.text);
        }
    }






    //get Update
    public static UpdateData checkUpdate(int turn)
    {
        // Create a UnityWebRequest object
        UnityWebRequest request = UnityWebRequest.Get("https://jsonplaceholder.typicode.com/todos/1");

        // Send the request and wait for a response
        //yield return request.SendWebRequest();

        // Check for errors
        if (request.result != UnityWebRequest.Result.Success)
        {
            Debug.Log(request.error);
            return null;
        }
        else
        {
            Debug.Log(request.downloadHandler.text);
            UpdateData updateData = JsonUtility.FromJson<UpdateData>(request.downloadHandler.text);
            return updateData;
        }
    }




    //play draw
    public static void play(Vector2 from,Vector2 to)
    {
        // Create a UnityWebRequest object
        UnityWebRequest request = UnityWebRequest.Get("https://jsonplaceholder.typicode.com/todos/1");

        // Send the request and wait for a response
        //yield return request.SendWebRequest();

        // Check for errors
        if (request.result != UnityWebRequest.Result.Success)
        {
            Debug.Log(request.error);
        }
        else
        {
            // Print the response body
            Debug.Log(request.downloadHandler.text);
        }
    }

    //surrender
    public static void surrender()
    {
        // Create a UnityWebRequest object
        UnityWebRequest request = UnityWebRequest.Get("https://jsonplaceholder.typicode.com/todos/1");

        // Send the request and wait for a response
        //yield return request.SendWebRequest();

        // Check for errors
        if (request.result != UnityWebRequest.Result.Success)
        {
            Debug.Log(request.error);
        }
        else
        {
            // Print the response body
            Debug.Log(request.downloadHandler.text);
        }
    }

}
