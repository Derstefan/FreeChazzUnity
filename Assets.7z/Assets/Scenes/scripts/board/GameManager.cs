using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{

    //data about me
    private string userid;
    private string token;

    //data about the game
    private string gameId;


    // Gamestate
    private Piece[,] pieces;
    private List<Piece> pieceList = new List<Piece>();
    private int turn;

    //Frontend State

    
    private int selectedX = -1; //-1,-1 means there is no selection
    private int selectedY = -1;
    private List<Vector2> possibleMoves = new List<Vector2>();



    //History


    //technical stuff
    
    public GameObject chessboard;
    public Material lightSquareMaterial;
    public Material darkSquareMaterial; 
    public GameObject pieceView;
    private int size;
    private int width;
    private int height;

    private BoardDrawer drawer;



    private float timer = 0.0f;
    private float interval = 0.5f; // 200ms


    void Start()
    {
        //connect (auth....)
        //load game data

        StartCoroutine(GameService.Example());

        //-> loaded chess data
        size = 1;
        width = 15;
        height = 15;
        turn = 0;
        pieces = new Piece[width, height];
        drawer = new BoardDrawer(chessboard.transform, width, height, size);

       drawChessboard();



       UpdateMatchData(UpdateData.mockUpdateData1);
       UpdateMatchData(UpdateData.mockUpdateData2);
    }






    void Update()
    {
        if (Input.GetButtonDown("Fire1"))
        {
            int i, j;
            if (TryGetGridPosition(out i, out j))
            {
                click(i, j);
            }
        }


        timer += Time.deltaTime;

        if (timer >= interval)
        {
            //Debug.Log("TODO: check for update ");
            timer = 0.0f; // Reset the timer
        }
    }




    private void checkForUpdate(){
        //TODO Update request
        //if( new update)
//        turn++;
//        UpdateMatchData(updateData);

    }

    
private void UpdateMatchData(UpdateData updateData)
{
    Debug.Log(" ------------------------------ new Board Update");
    
    List<Piece> piecesToDestroy = new List<Piece>();
    List<Piece> piecesToAdd = new List<Piece>();

    foreach (PieceDTO pDTO in updateData.pieceDTOs)
    {
        Piece existingPiece = getPieceById(pDTO.id);
        if (existingPiece != null)
        {
            if(!existingPiece.pos.equals(pDTO.pos)){
                movePiece(existingPiece,pDTO.pos);
            }else {
                //case no change
                Debug.Log("no change Piece " + existingPiece.id + " to (" + existingPiece.pos.x +","+ existingPiece.pos.y+")");
            }
        }
        else
        {
            piecesToAdd.Add(new Piece(pDTO));
        }
    }

    foreach (Piece p in pieceList)
    {
        if(getPieceDTOById(p.id,updateData.pieceDTOs)==null){
            piecesToDestroy.Add(p);
        }
    }


    foreach (Piece p in piecesToAdd)
    {
        addPiece(p);
    }
    foreach (Piece p in piecesToDestroy)
    {
        destroy(p);
    }

}





    private void addPiece(Piece p){
        pieces[p.pos.x, p.pos.y] = p;
        pieceList.Add(p);
        
        drawer.CreatePieceObject(p);
        Debug.Log("added Piece " + p.id + " to (" + p.pos.x +","+ p.pos.y+")");
    }

    private void movePiece(Piece p, Pos pos){
        pieces[p.pos.x, p.pos.y] = null;
        pieces[pos.x, pos.y] = p;
        p.pos.x = pos.x;
        p.pos.y = pos.y;

        p.gameObject.transform.localPosition = new Vector3(p.pos.x * size + size/2f, -p.pos.y * size - size/2f, 0);
        Debug.Log("moved Piece " + p.id + " to (" + pos.x +","+pos.y+")");
    }

    private void destroy(Piece p){
        pieces[p.pos.x, p.pos.y] = null;
        pieceList.Remove(p);

        Destroy(p.gameObject);
        Debug.Log("destroyed Piece " + p.id);
    }

    private Piece getPieceById(string id)
    {
        foreach (Piece piece in pieceList)
        {
            if (piece != null && piece.id == id)
            {
                return piece;
            }
        }
        return null;
    }

    private PieceDTO getPieceDTOById(string id,List<PieceDTO> pDTOs)
    {
        foreach (PieceDTO pDTO in pDTOs)
        {
            if (pDTO != null && pDTO.id == id)
            {
                return pDTO;
            }
        }
        return null;
    }




    private void click(int x,int y)
    {
        if(pieces[x, y]!=null){
            selectedX = x;
            selectedY = y;
            Debug.Log("Clicked square: (" + selectedX + ", " + selectedY + ") (" + pieces[x, y].symbol+")");
        }else if(isPossibleMove(x,y)) {
            Debug.Log("Possible move");
            GameService.play(new Vector2(selectedX,selectedY),new Vector2(x,y));
        }
        else {
            selectedX = -1;
            selectedY = -1;
        }
    }

    private bool isPossibleMove(int x,int y){
        Debug.Log("blabla (" + selectedX + ", " + selectedY + ") (" + x + ","+y+")");
        if(selectedX==-1 && selectedY==-1)return false;
        return pieces[selectedX, selectedY].possibleMoves.Contains(new Pos(x-selectedX,y-selectedY));
    }



    //-------------------------------------rest-----------------------------------


    void drawChessboard(){
        drawer.CreateChessboard(lightSquareMaterial, darkSquareMaterial);
    }


    private bool TryGetGridPosition(out int i, out int j)
    {
        Vector3 worldPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        i = Mathf.FloorToInt(worldPos.x / size);
        j = Mathf.FloorToInt(-worldPos.y / size);
        if (i >= 0 && i < width && j >= 0 && j < height)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    




    
}
