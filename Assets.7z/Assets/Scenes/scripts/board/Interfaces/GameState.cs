using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameState
{
    public Piece[,] pieces;
    public List<Piece> pieceList = new List<Piece>();


    public void addPiece(Piece p){
        pieces[p.pos.x, p.pos.y] = p;
        pieceList.Add(p);
    }

    public void movePiece(Piece p, Pos pos){
        pieces[p.pos.x, p.pos.y] = null;
        pieces[pos.x, pos.y] = p;
        p.pos.x = pos.x;
        p.pos.y = pos.y;
    }

    public void destroy(Piece p){
        pieces[p.pos.x, p.pos.y] = null;
        pieceList.Remove(p);
    }
}
