using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Piece
{
    public string id { get; set; }
    public PieceType pieceType { get; set; }
    public Pos pos { get; set; }
    public string symbol { get; set; }
    public List<Pos> possibleMoves { get; set; }
    public EPlayer owner { get; set; }

    public GameObject gameObject { get; set; }


    public Piece(PieceDTO pieceDTO)
    {
        id = pieceDTO.id;
        pieceType = pieceDTO.pieceType;
        pos = pieceDTO.pos;
        symbol = pieceDTO.symbol;
        possibleMoves = pieceDTO.possibleMoves;
        owner = pieceDTO.owner;
    }


    public void assignGameObject(GameObject obj){
        gameObject = obj;
    }

        public static Piece mockPiece1 =  new Piece(PieceDTO.mockPieceDTO1);
        public static Piece mockPiece2 =  new Piece(PieceDTO.mockPieceDTO2);
    
}