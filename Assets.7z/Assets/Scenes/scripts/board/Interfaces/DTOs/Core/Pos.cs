using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pos
{
    public int x { get; set; }
    public int y { get; set; }

    public Pos(int x, int y)
    {
        this.x = x;
        this.y = y;
    }

    public Vector2 GetVector2()
    {
        return new Vector2(x, y);
    }

    public bool equals(Pos other)
    {
        return this.x == other.x && this.y == other.y;
    }
}
