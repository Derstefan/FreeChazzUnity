public enum EPlayer
{
    P1,
    P2
}