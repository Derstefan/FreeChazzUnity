using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PieceType
{

    public string typeId { get; set; }
    public List<Action> actions { get; set; }

    public static PieceType mockType1 = new PieceType
            {
                typeId = "Pawn",
                actions = new List<Action>
                {
                    new Action
                    {
                        vec = new Pos(1, 0),
                        type = "Move"
                    },
                    new Action
                    {
                        vec = new Pos(1, 1),
                        type = "Capture"
                    }
                }
            };


        public static PieceType mockType2 = new PieceType
            {
                typeId = "Pawnasdw",
                actions = new List<Action>
                {
                    new Action
                    {
                        vec = new Pos(2, 0),
                        type = "Move"
                    },
                    new Action
                    {
                        vec = new Pos(0, 4),
                        type = "Capture"
                    }
                }
            };


            public static PieceType mockType3 = new PieceType
            {
                typeId = "Pawnasdasdwsw",
                actions = new List<Action>
                {
                    new Action
                    {
                        vec = new Pos(2, 0),
                        type = "Move"
                    },
                    new Action
                    {
                        vec = new Pos(0, 4),
                        type = "Capture"
                    }
                }
            };

            public static PieceType mockType4 = new PieceType
            {
                typeId = "Pawnasdasdwsw",
                actions = new List<Action>
                {
                    new Action
                    {
                        vec = new Pos(2, 0),
                        type = "Move"
                    },
                    new Action
                    {
                        vec = new Pos(0, 4),
                        type = "Capture"
                    }
                }
            };

}
