#nullable enable

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UpdateData
{
    public int drawCounter { get; set; }
    public long lastDraw { get; set; }
    public EPlayer? winner { get; set; }

    //optional data if new turn -> this is set
    public List<PieceDTO>? pieceDTOs { get; set; }




    public static UpdateData mockUpdateData1 = new UpdateData
{
    drawCounter = 3,
    lastDraw = 1623478800, // Example timestamp
    pieceDTOs = new List<PieceDTO>
    {
       PieceDTO.mockPieceDTO1,
       PieceDTO.mockPieceDTO2,
       PieceDTO.mockPieceDTO3,
    }
};

    public static UpdateData mockUpdateData2 = new UpdateData
{
    drawCounter = 4,
    lastDraw = 1623478800232, // Example timestamp
    winner = EPlayer.P1,
    pieceDTOs = new List<PieceDTO>
    {
       PieceDTO.mockPieceDTO2Moved,
       PieceDTO.mockPieceDTO3,
       PieceDTO.mockPieceDTO4,
    }
};

}
